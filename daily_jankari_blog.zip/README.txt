DAILY JANKARI BLOG
यह एक तैयार static blog homepage है।
index.html को browser में खोलकर preview कर सकते हैं।
Online publish करने के लिए इसे किसी hosting service पर upload करें।
